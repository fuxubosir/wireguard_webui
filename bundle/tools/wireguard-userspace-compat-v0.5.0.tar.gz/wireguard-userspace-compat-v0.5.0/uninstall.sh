#!/usr/bin/env bash
set -euo pipefail
WG_IF="${WG_IF:-wg0}"
WG_CONF="/etc/wireguard/${WG_IF}.conf"
WG_GO="/usr/local/bin/wireguard-go"

stop_service(){
  wg-quick down "$WG_IF" >/dev/null 2>&1 || true
  ip link delete "$WG_IF" >/dev/null 2>&1 || true
  systemctl stop "wg-quick@${WG_IF}" 2>/dev/null || true
  systemctl disable "wg-quick@${WG_IF}" 2>/dev/null || true
  systemctl reset-failed "wg-quick@${WG_IF}" 2>/dev/null || true
}
clean_dropin(){
  rm -f /etc/systemd/system/wg-quick@.service.d/override.conf
  rmdir /etc/systemd/system/wg-quick@.service.d 2>/dev/null || true
  systemctl daemon-reload
}
clean_rules(){
  for oif in eth0 wlan0 end0 enp0s3 enp1s0; do
    iptables -t nat -D POSTROUTING -s 10.6.0.0/24 -o "$oif" -j MASQUERADE 2>/dev/null || true
    iptables -D FORWARD -i "$WG_IF" -o "$oif" -s 10.6.0.0/24 -j ACCEPT 2>/dev/null || true
    iptables -D FORWARD -i "$oif" -o "$WG_IF" -d 10.6.0.0/24 -m conntrack --ctstate RELATED,ESTABLISHED -j ACCEPT 2>/dev/null || true
  done
}
menu(){
  echo "========== 卸载 =========="
  echo "1) 停止服务，保留配置"
  echo "2) 删除用户态程序，保留配置"
  echo "3) 完全删除，包括 wg0.conf"
  echo "0) 退出"
  read -r -p "选择: " c
  case "$c" in
    1) stop_service; clean_dropin; clean_rules; echo "完成";;
    2) stop_service; clean_dropin; clean_rules; rm -f "$WG_GO"; rm -rf /opt/go /usr/local/src/wireguard-go /tmp/wireguard-userspace-compat; echo "完成";;
    3) read -r -p "输入 DELETE 确认删除配置: " a; [ "$a" = "DELETE" ] || exit 1; stop_service; clean_dropin; clean_rules; rm -f "$WG_GO" "$WG_CONF"; rm -rf /opt/go /usr/local/src/wireguard-go /tmp/wireguard-userspace-compat; echo "完成";;
    0) exit 0;;
    *) echo "无效选择"; exit 1;;
  esac
}
[ "$(id -u)" -eq 0 ] || { echo "请用 root 执行"; exit 1; }
menu
