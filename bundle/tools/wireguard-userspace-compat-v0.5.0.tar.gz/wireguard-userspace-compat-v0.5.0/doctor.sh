#!/usr/bin/env bash
set -euo pipefail
echo "========== 环境检查 =========="
uname -a
[ -e /dev/net/tun ] && echo "[OK] TUN 可用" || echo "[失败] TUN 不存在"
command -v wg >/dev/null && echo "[OK] wg 存在" || echo "[失败] wg 不存在"
command -v wg-quick >/dev/null && echo "[OK] wg-quick 存在" || echo "[失败] wg-quick 不存在"
dpkg --audit || true
systemctl --failed || true
